<?php if($paginator->hasPages()): ?>
    <nav>
        <ul class="pagination flex gap-7">
            
            <?php if($paginator->onFirstPage()): ?>
                <li class="disabled flex items-center" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>">
                    <span aria-hidden="true" class="bg-[#545454] py-5 w-20 text-white font-ibm uppercase">before</span>
                </li>
            <?php else: ?>
                <li class="flex items-center">
                    <a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev" aria-label="<?php echo app('translator')->get('pagination.previous'); ?>" class="bg-[#545454] py-5 w-20 text-white font-ibm uppercase">before</a>
                </li>
            <?php endif; ?>


            
            <?php if($paginator->hasMorePages()): ?>
                <li class="flex items-center">
                    <a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next" aria-label="<?php echo app('translator')->get('pagination.next'); ?>" class="bg-[#545454] py-5 w-20 text-white font-ibm uppercase">after</a>
                </li>
            <?php else: ?>
                <li class="flex items-center disabled" aria-disabled="true" aria-label="<?php echo app('translator')->get('pagination.next'); ?>">
                    <span aria-hidden="true" class="bg-[#545454] py-5 w-20 text-white font-ibm uppercase">after</span>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
<?php endif; ?><?php /**PATH C:\Users\user\defusethebomb-ti\resources\views/vendor/pagination/custom.blade.php ENDPATH**/ ?>