<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <title>Document</title>
</head>
<body>
<div id="bomb-1">
        <p id="bombnumber"></p>
        <p id="timer-1"></p>
        <p id="timerms-1"></p>
    
        <input type="text" name="" id="code-1" class="border-2 border-black rounded-md">
        <p id="kodesalah-1"></p>
        <p id="kodebenar-1"></p>
    
        <button id="defuse-1">CANCEL</button>
        <button id="refresh-1" style="display: none;">NEXT</button>
    </div>
<script>
        var j = 1;
        var timer;
        
        timerStart(j);
        
        function timerStart(i) {
            document.getElementById("bombnumber").innerHTML = "Bomb Nomor " + i;
            var count = 300 * 100;
            clearInterval(timer)
            timer = setInterval(function() {
                count--;
                var minutes = Math.floor(count / (60*100));
                var seconds = Math.floor((count - minutes * 60 * 100) / 100);
                var ms = count - Math.floor(count/100) * 100;
                document.getElementById("timer-" + i).innerHTML = minutes + " : " + seconds + " : " + ms;
                document.getElementById("timerms-" + i).innerHTML = "total miliseconds = " + count;
                if (count === 0) {
                    clearInterval(timer);
                    document.getElementById("timer-" + i).innerHTML = "MELEDAK";
                }
            }, 10);
        }
        
        document.getElementById("defuse-" + j).addEventListener("click", function(){
            var check = document.getElementById("code-" + j).value;
            alert(check)
            if (check === "123"){
                clearInterval(timer);
                document.getElementById("kodesalah-" + j).innerHTML = "";
                document.getElementById("kodebenar-" + j).innerHTML = "Selamat bom berhasil dijinakan" + j;
                document.getElementById("refresh-" + j).style.display = "inline";
            } else {
                document.getElementById("kodesalah-" + j).innerHTML = "KODE SALAH";
            }
        });

        document.getElementById("refresh-" + j).addEventListener("click", function(){
            document.getElementById("refresh-" + j).style.display = "none";
            document.getElementById("kodebenar-" + j).innerHTML = "";
            var check = document.getElementById("code-" + j).value = "";
            clearInterval(timer);
            j++;
            timerStart(j);
        });
</script>
</body>
</html><?php /**PATH C:\Users\user\defusethebomb-ti\resources\views//defusethebomb/index.blade.php ENDPATH**/ ?>