<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Saira Condensed' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=IBM Plex Sans Condensed' rel='stylesheet'>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>


    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: {
                        poppins: ['Poppins', 'sans-serif'],
                        montserrat: ["Montserrat", "sans-serif"],
                        saira: ['Saira Condensed', "sans-serif"],
                        ibm: ['IBM Plex Sans Condensed', 'sans-serif'],
                        sSegment: ['Seven Segment', 'sans-serif'],
                        anon: ['Anonymous Pro', 'sans-serif']
                    },
                    colors: {
                        primary: '#FF914D',
                        secondary: '#ED3237',
                        gray: '#545454',
                        gold: '#FFFF00',
                    }
                },
            },
        }
        // $teamsix [2/3]
        // $passcode (kirim ketika mau main)
        // $admin (kirim ketika mau main)
    </script>
    <title>TEAM SIX 2</title>
</head>
<body class="bg-black">
    <!-- <h1 class="text-4xl text-white"><?php echo e($teamsix); ?></h1> -->
    <h1 class="mt-8 text-4xl md:text-8xl text-primary text-center font-ibm font-black tracking-widest">PILIHAN MISI</h1>
    <div class="md:grid md:grid-cols-4 md:gap-8 mt-4 md:mt-12 mx-4 md:mx-16">
        <div class="<?php if($teamsix == '2'): ?> bg-secondary <?php else: ?> bg-secondary/75 <?php endif; ?> max-md:mb-2 px-4 py-2 md:py-6 rounded-xl">
            <h1 class="max-md:hidden text-lg text-white text-left font-ibm tracking-wide"><?php if($teamsix == '2'): ?> THE BEGINNING <?php else: ?> THE LAST TEST <?php endif; ?></h1>
            <h1 class="max-md:hidden text-4xl text-white text-left font-ibm font-black tracking-widest">TEAM SIX <?php if($teamsix == '2'): ?> 2 <?php else: ?> 3 <?php endif; ?></h1>
            <h1 class="md:hidden text-xl text-white text-center font-ibm font-black tracking-widest"><?php if($teamsix == '2'): ?> THE BEGINNING - TEAM SIX 2 <?php else: ?> THE LAST TEST - TEAM SIX 3 <?php endif; ?></h1>
        </div>
        <div class="bg-white max-md:mb-2 px-4 py-3 rounded-xl <?php if($teamsix == '2'): ?> md:opacity-50 <?php endif; ?>">
            <h1 class="max-md:hidden text-sm text-black font-ibm tracking-wide">MISSION 1</h1>
            <h1 class="md:hidden text-sm text-black font-ibm tracking-wide">MISSION 0</h1>
            <h1 class="max-md:hidden -mt-1 text-base text-black font-ibm font-black tracking-widest">CENTRAL STATION</h1>
            <h1 class="md:hidden -mt-1 text-base text-black font-ibm font-black tracking-widest">TRAINING MISSION</h1>
            <div class="flex mb-1">
                <img src="<?php echo e(asset('dist/bomb.svg')); ?>" alt="">
                <h1 class="max-md:hidden ml-2 text-sm text-slate-500 font-ibm font-bold">5 BOMB</h1>
                <h1 class="md:hidden ml-2 text-sm text-slate-500 font-ibm font-bold">3 BOMB</h1>
            </div>
            <div class="flex mb-1">
                <img src="<?php echo e(asset('dist/time.svg')); ?>" alt="">
                <h1 class="max-md:hidden ml-2 text-sm text-slate-500 font-ibm font-bold">15:00</h1>
                <h1 class="md:hidden ml-2 text-sm text-slate-500 font-ibm font-bold">10:00</h1>
            </div>
            <div class="flex w-fit -mb-6 gap-[1px]">
                <img src="<?php echo e(asset('dist/difficulty.svg')); ?>" alt="">
                <div class="ml-2 bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="md:bg-slate-500 rounded-full border-2 md:border-0 border-slate-500 w-4 h-4"></div>
                <div class="border-2 border-slate-500 rounded-full w-4 h-4"></div>
                <div class="border-2 border-slate-500 rounded-full w-4 h-4"></div>
                <div class="border-2 border-slate-500 rounded-full w-4 h-4"></div>
            </div>
            <?php if($teamsix == '3'): ?>
            <div class="justify-end flex max-md:hidden">
                <button class="mr-0 w-fit bg-secondary px-4 py-1 rounded-lg text-base text-white font-ibm font-bold tracking-widest hover:bg-secondary/75"> 
                    <a href="<?php echo e(route('teamsix.show', ['admin' => $admin, 'missionnum' => '1' , 'passcode' => $passcode, 'teamsix' => $teamsix])); ?>">PLAY</a>
                </button>
            </div>
            <?php endif; ?>
            <div class="justify-end flex md:hidden">
                <button class="mr-0 w-fit bg-secondary px-4 py-1 rounded-lg text-base text-white font-ibm font-bold tracking-widest hover:bg-secondary/75"> 
                    <a href="<?php echo e(route('teamsix.show', ['admin' => $admin, 'missionnum' => '0' , 'passcode' => $passcode, 'teamsix' => $teamsix])); ?>">PLAY</a>
                </button>
            </div>
        </div>
        <div class="bg-white max-md:mb-2 px-4 py-3 rounded-xl <?php if($teamsix == '2'): ?> max-md:opacity-50 <?php else: ?> md:opacity-50 <?php endif; ?>">
            <h1 class="max-md:hidden text-sm text-black font-ibm tracking-wide">MISSION 4</h1>
            <h1 class="md:hidden text-sm text-black font-ibm tracking-wide">MISSION 1</h1>
            <h1 class="max-md:hidden -mt-1 text-base text-black font-ibm font-black tracking-widest">ROLLER COASTER</h1>
            <h1 class="md:hidden -mt-1 text-base text-black font-ibm font-black tracking-widest">CENTRAL STATION</h1>
            <div class="flex mb-1">
                <img src="<?php echo e(asset('dist/bomb.svg')); ?>" alt="">
                <h1 class="ml-2 text-sm text-slate-500 font-ibm font-bold">5 BOMB</h1>
            </div>
            <div class="flex mb-1">
                <img src="<?php echo e(asset('dist/time.svg')); ?>" alt="">
                <h1 class="max-md:hidden ml-2 text-sm text-slate-500 font-ibm font-bold">30:00</h1>
                <h1 class="md:hidden ml-2 text-sm text-slate-500 font-ibm font-bold">15:00</h1>
            </div>
            <div class="flex w-fit -mb-6 gap-[1px]">
                <img src="<?php echo e(asset('dist/difficulty.svg')); ?>" alt="">
                <div class="ml-2 bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="md:bg-slate-500 rounded-full border-2 md:border-0 border-slate-500 w-4 h-4"></div>
                <div class="border-2 border-slate-500 rounded-full w-4 h-4"></div>
                <div class="border-2 border-slate-500 rounded-full w-4 h-4"></div>
            </div>
            <?php if($teamsix == '2'): ?> 
            <div class="justify-end flex max-md:hidden">
                <button class="mr-0 w-fit bg-secondary px-4 py-1 rounded-lg text-base text-white font-ibm font-bold tracking-widest hover:bg-secondary/75"> 
                    <a href="<?php echo e(route('teamsix.show', ['admin' => $admin, 'missionnum' => '4' , 'passcode' => $passcode, 'teamsix' => $teamsix])); ?>">PLAY</a>
                </button>
            </div>
            <?php endif; ?>
            <?php if($teamsix == '3'): ?>
            <div class="justify-end flex md:hidden">
                <button class="mr-0 w-fit bg-secondary px-4 py-1 rounded-lg text-base text-white font-ibm font-bold tracking-widest hover:bg-secondary/75"> 
                    <a href="<?php echo e(route('teamsix.show', ['admin' => $admin, 'missionnum' => '1' , 'passcode' => $passcode, 'teamsix' => $teamsix])); ?>">PLAY</a>
                </button>
            </div>
            <?php else: ?>
            <div class="md:hidden mb-8"></div>
            <?php endif; ?>
        </div>
        <div class="bg-white max-md:mb-2 px-4 py-3 rounded-xl <?php if($teamsix == '2'): ?> md:opacity-50 <?php else: ?> max-md:opacity-50 <?php endif; ?>">
            <h1 class="max-md:hidden text-sm text-black font-ibm tracking-wide">MISSION 7</h1>
            <h1 class="md:hidden text-sm text-black font-ibm tracking-wide">MISSION 2</h1>
            <h1 class="max-md:hidden -mt-1 text-base text-black font-ibm font-black tracking-widest">PRISON</h1>
            <h1 class="md:hidden -mt-1 text-base text-black font-ibm font-black tracking-widest">TERMINAL</h1>
            <div class="flex mb-1">
                <img src="<?php echo e(asset('dist/bomb.svg')); ?>" alt="">
                <h1 class="ml-2 text-sm text-slate-500 font-ibm font-bold">5 BOMB</h1>
            </div>
            <div class="flex mb-1">
                <img src="<?php echo e(asset('dist/time.svg')); ?>" alt="">
                <h1 class="max-md:hidden ml-2 text-sm text-slate-500 font-ibm font-bold">40:00</h1>
                <h1 class="md:hidden ml-2 text-sm text-slate-500 font-ibm font-bold">15:00</h1>
            </div>
            <div class="flex w-fit -mb-6 gap-[1px]">
                <img src="<?php echo e(asset('dist/difficulty.svg')); ?>" alt="">
                <div class="ml-2 bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="md:bg-slate-500 rounded-full border-2 md:border-0 border-slate-500 w-4 h-4"></div>
                <div class="md:bg-slate-500 rounded-full border-2 md:border-0 border-slate-500 w-4 h-4"></div>
                <div class="border-2 border-slate-500 rounded-full w-4 h-4"></div>
            </div>
            <?php if($teamsix == '3'): ?>
            <div class="justify-end flex max-md:hidden">
                <button class="mr-0 w-fit bg-secondary px-4 py-1 rounded-lg text-base text-white font-ibm font-bold tracking-widest hover:bg-secondary/75"> 
                    <a href="<?php echo e(route('teamsix.show', ['admin' => $admin, 'missionnum' => '7' , 'passcode' => $passcode, 'teamsix' => $teamsix])); ?>">PLAY</a>
                </button>
            </div>
            <?php endif; ?>
            <?php if($teamsix == '2'): ?>
            <div class="justify-end flex md:hidden">
                <button class="mr-0 w-fit bg-secondary px-4 py-1 rounded-lg text-base text-white font-ibm font-bold tracking-widest hover:bg-secondary/75"> 
                    <a href="<?php echo e(route('teamsix.show', ['admin' => $admin, 'missionnum' => '2' , 'passcode' => $passcode, 'teamsix' => $teamsix])); ?>">PLAY</a>
                </button>
            </div>
            <?php else: ?>
            <div class="md:hidden mb-8"></div>
            <?php endif; ?>
        </div>
        <div class="bg-white max-md:mb-2 px-4 py-3 rounded-xl <?php if($teamsix == '2'): ?> max-md:opacity-50 <?php endif; ?>">
            <h1 class="max-md:hidden text-sm text-black font-ibm tracking-wide">MISSION 0</h1>
            <h1 class="md:hidden text-sm text-black font-ibm tracking-wide">MISSION 3</h1>
            <h1 class="max-md:hidden -mt-1 text-base text-black font-ibm font-black tracking-widest">TRAINING MISSION</h1>
            <h1 class="md:hidden -mt-1 text-base text-black font-ibm font-black tracking-widest">ELEVATOR</h1>
            <div class="flex mb-1">
                <img src="<?php echo e(asset('dist/bomb.svg')); ?>" alt="">
                <h1 class="max-md:hidden ml-2 text-sm text-slate-500 font-ibm font-bold">3 BOMB</h1>
                <h1 class="md:hidden ml-2 text-sm text-slate-500 font-ibm font-bold">5 BOMB</h1>
            </div>
            <div class="flex mb-1">
                <img src="<?php echo e(asset('dist/time.svg')); ?>" alt="">
                <h1 class="max-md:hidden ml-2 text-sm text-slate-500 font-ibm font-bold">10:00</h1>
                <h1 class="md:hidden ml-2 text-sm text-slate-500 font-ibm font-bold">30:00</h1>
            </div>
            <div class="flex w-fit -mb-6 gap-[1px]">
                <img src="<?php echo e(asset('dist/difficulty.svg')); ?>" alt="">
                <div class="ml-2 bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="bg-slate-500 md:bg-transparent border-0 md:border-2 border-slate-500 rounded-full w-4 h-4"></div>
                <div class="bg-slate-500 md:bg-transparent border-0 md:border-2 border-slate-500 rounded-full w-4 h-4"></div>
                <div class="border-2 border-slate-500 rounded-full w-4 h-4"></div>
                <div class="border-2 border-slate-500 rounded-full w-4 h-4"></div>
            </div>
            <div class="justify-end flex max-md:hidden">
                <button class="mr-0 w-fit bg-secondary px-4 py-1 rounded-lg text-base text-white font-ibm font-bold tracking-widest hover:bg-secondary/75"> 
                    <a href="<?php echo e(route('teamsix.show', ['admin' => $admin, 'missionnum' => '0' , 'passcode' => $passcode, 'teamsix' => $teamsix])); ?>">PLAY</a>
                </button>
            </div>
            <?php if($teamsix == '3'): ?>
            <div class="justify-end flex md:hidden">
                <button class="mr-0 w-fit bg-secondary px-4 py-1 rounded-lg text-base text-white font-ibm font-bold tracking-widest hover:bg-secondary/75"> 
                    <a href="<?php echo e(route('teamsix.show', ['admin' => $admin, 'missionnum' => '3' , 'passcode' => $passcode, 'teamsix' => $teamsix])); ?>">PLAY</a>
                </button>
            </div>
            <?php else: ?>
            <div class="md:hidden mb-8"></div>
            <?php endif; ?>
        </div>
        <div class="bg-white max-md:mb-2 px-4 py-3 rounded-xl <?php if($teamsix == '3'): ?> opacity-50 <?php endif; ?>">
            <h1 class="max-md:hidden text-sm text-black font-ibm tracking-wide">MISSION 2</h1>
            <h1 class="md:hidden text-sm text-black font-ibm tracking-wide">MISSION 4</h1>
            <h1 class="max-md:hidden -mt-1 text-base text-black font-ibm font-black tracking-widest">TERMINAL</h1>
            <h1 class="md:hidden -mt-1 text-base text-black font-ibm font-black tracking-widest">ROLLERCOASTER</h1>
            <div class="flex mb-1">
                <img src="<?php echo e(asset('dist/bomb.svg')); ?>" alt="">
                <h1 class="ml-2 text-sm text-slate-500 font-ibm font-bold">5 BOMB</h1>
            </div>
            <div class="flex mb-1">
                <img src="<?php echo e(asset('dist/time.svg')); ?>" alt="">
                <h1 class="max-md:hidden ml-2 text-sm text-slate-500 font-ibm font-bold">20:00</h1>
                <h1 class="md:hidden ml-2 text-sm text-slate-500 font-ibm font-bold">30:00</h1>
            </div>
            <div class="flex w-fit -mb-6 gap-[1px]">
                <img src="<?php echo e(asset('dist/difficulty.svg')); ?>" alt="">
                <div class="ml-2 bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="bg-slate-500 md:bg-transparent border-0 md:border-2 border-slate-500 rounded-full w-4 h-4"></div>
                <div class="border-2 border-slate-500 rounded-full w-4 h-4"></div>
                <div class="border-2 border-slate-500 rounded-full w-4 h-4"></div>
            </div>
            <?php if($teamsix == '2'): ?>
            <div class="justify-end flex max-md:hidden">
                <button class="mr-0 w-fit bg-secondary px-4 py-1 rounded-lg text-base text-white font-ibm font-bold tracking-widest hover:bg-secondary/75"> 
                    <a href="<?php echo e(route('teamsix.show', ['admin' => $admin, 'missionnum' => '2' , 'passcode' => $passcode, 'teamsix' => $teamsix])); ?>">PLAY</a>
                </button>
            </div>
            <?php else: ?>
            <div class="md:hidden mb-8"></div>
            <?php endif; ?>
            <?php if($teamsix == '2'): ?>
            <div class="justify-end flex md:hidden">
                <button class="mr-0 w-fit bg-secondary px-4 py-1 rounded-lg text-base text-white font-ibm font-bold tracking-widest hover:bg-secondary/75"> 
                    <a href="<?php echo e(route('teamsix.show', ['admin' => $admin, 'missionnum' => '4' , 'passcode' => $passcode, 'teamsix' => $teamsix])); ?>">PLAY</a>
                </button>
            </div>
            <?php else: ?>
            <div class="md:hidden mb-8"></div>
            <?php endif; ?>
        </div>
        <div class="bg-white max-md:mb-2 px-4 py-3 rounded-xl <?php if($teamsix == '2'): ?> opacity-50 <?php endif; ?>">
            <h1 class="text-sm text-black font-ibm tracking-wide">MISSION 5</h1>
            <h1 class="-mt-1 text-base text-black font-ibm font-black tracking-widest">SUBWAY</h1>
            <div class="flex mb-1">
                <img src="<?php echo e(asset('dist/bomb.svg')); ?>" alt="">
                <h1 class="ml-2 text-sm text-slate-500 font-ibm font-bold">5 BOMB</h1>
            </div>
            <div class="flex mb-1">
                <img src="<?php echo e(asset('dist/time.svg')); ?>" alt="">
                <h1 class="ml-2 text-sm text-slate-500 font-ibm font-bold">30:00</h1>
            </div>
            <div class="flex w-fit -mb-6 gap-[1px]">
                <img src="<?php echo e(asset('dist/difficulty.svg')); ?>" alt="">
                <div class="ml-2 bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="border-2 border-slate-500 rounded-full w-4 h-4"></div>
                <div class="border-2 border-slate-500 rounded-full w-4 h-4"></div>
            </div>
            <?php if($teamsix == '3'): ?>
            <div class="justify-end flex">
                <button class="mr-0 w-fit bg-secondary px-4 py-1 rounded-lg text-base text-white font-ibm font-bold tracking-widest hover:bg-secondary/75"> 
                    <a href="<?php echo e(route('teamsix.show', ['admin' => $admin, 'missionnum' => '5' , 'passcode' => $passcode, 'teamsix' => $teamsix])); ?>">PLAY</a>
                </button>
            </div>
            <?php else: ?>
            <div class="md:hidden mb-8"></div>
            <?php endif; ?>
        </div>
        <div class="bg-white max-md:mb-2 px-4 py-3 rounded-xl <?php if($teamsix == '3'): ?> opacity-50 <?php endif; ?>">
            <h1 class="max-md:hidden text-sm text-black font-ibm tracking-wide">MISSION 8</h1>
            <h1 class="md:hidden text-sm text-black font-ibm tracking-wide">MISSION 6</h1>
            <h1 class="max-md:hidden -mt-1 text-base text-black font-ibm font-black tracking-widest">BUS</h1>
            <h1 class="md:hidden -mt-1 text-base text-black font-ibm font-black tracking-widest">CRUISE SHIP</h1>
            <div class="flex mb-1">
                <img src="<?php echo e(asset('dist/bomb.svg')); ?>" alt="">
                <h1 class="ml-2 text-sm text-slate-500 font-ibm font-bold">5 BOMB</h1>
            </div>
            <div class="flex mb-1">
                <img src="<?php echo e(asset('dist/time.svg')); ?>" alt="">
                <h1 class="ml-2 text-sm text-slate-500 font-ibm font-bold">40:00</h1>
            </div>
            <div class="flex w-fit -mb-6 gap-[1px]">
                <img src="<?php echo e(asset('dist/difficulty.svg')); ?>" alt="">
                <div class="ml-2 bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="bg-transparent md:bg-slate-500 rounded-full border-2 md:border-0 border-slate-500 w-4 h-4"></div>
            </div>
            <?php if($teamsix == '2'): ?>
            <div class="justify-end flex max-md:hidden">
                <button class="mr-0 w-fit bg-secondary px-4 py-1 rounded-lg text-base text-white font-ibm font-bold tracking-widest hover:bg-secondary/75"> 
                    <a href="<?php echo e(route('teamsix.show', ['admin' => $admin, 'missionnum' => '8' , 'passcode' => $passcode, 'teamsix' => $teamsix])); ?>">PLAY</a>
                </button>
            </div>
            <?php else: ?>
            <div class="md:hidden mb-8"></div>
            <?php endif; ?>
            <?php if($teamsix == '2'): ?>
            <div class="justify-end flex md:hidden">
                <button class="mr-0 w-fit bg-secondary px-4 py-1 rounded-lg text-base text-white font-ibm font-bold tracking-widest hover:bg-secondary/75"> 
                    <a href="<?php echo e(route('teamsix.show', ['admin' => $admin, 'missionnum' => '6' , 'passcode' => $passcode, 'teamsix' => $teamsix])); ?>">PLAY</a>
                </button>
            </div>
            <?php else: ?>
            <div class="md:hidden mb-8"></div>
            <?php endif; ?>
        </div>
        <div class="">
        </div>
        <div class="bg-white max-md:mb-2 px-4 py-3 rounded-xl <?php if($teamsix == '2'): ?> opacity-50 <?php endif; ?>">
            <h1 class="max-md:hidden text-sm text-black font-ibm tracking-wide">MISSION 3</h1>
            <h1 class="md:hidden text-sm text-black font-ibm tracking-wide">MISSION 7</h1>
            <h1 class="max-md:hidden -mt-1 text-base text-black font-ibm font-black tracking-widest">ELEVATOR</h1>
            <h1 class="md:hidden -mt-1 text-base text-black font-ibm font-black tracking-widest">PRISON</h1>
            <div class="flex mb-1">
                <img src="<?php echo e(asset('dist/bomb.svg')); ?>" alt="">
                <h1 class="ml-2 text-sm text-slate-500 font-ibm font-bold">5 BOMB</h1>
            </div>
            <div class="flex mb-1">
                <img src="<?php echo e(asset('dist/time.svg')); ?>" alt="">
                <h1 class="max-md:hidden ml-2 text-sm text-slate-500 font-ibm font-bold">30:00</h1>
                <h1 class="md:hidden ml-2 text-sm text-slate-500 font-ibm font-bold">40:00</h1>
            </div>
            <div class="flex w-fit -mb-6 gap-[1px]">
                <img src="<?php echo e(asset('dist/difficulty.svg')); ?>" alt="">
                <div class="ml-2 bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="bg-slate-500 md:bg-transparent border-0 md:border-2 border-slate-500 rounded-full w-4 h-4"></div>
                <div class="border-2 border-slate-500 rounded-full w-4 h-4"></div>
            </div>
            <?php if($teamsix == '3'): ?>
            <div class="justify-end flex max-md:hidden">
                <button class="mr-0 w-fit bg-secondary px-4 py-1 rounded-lg text-base text-white font-ibm font-bold tracking-widest hover:bg-secondary/75"> 
                    <a href="<?php echo e(route('teamsix.show', ['admin' => $admin, 'missionnum' => '3' , 'passcode' => $passcode, 'teamsix' => $teamsix])); ?>">PLAY</a>
                </button>
            </div>
            <?php else: ?>
            <div class="md:hidden mb-8"></div>
            <?php endif; ?>
            <?php if($teamsix == '3'): ?>
            <div class="justify-end flex md:hidden">
                <button class="mr-0 w-fit bg-secondary px-4 py-1 rounded-lg text-base text-white font-ibm font-bold tracking-widest hover:bg-secondary/75"> 
                    <a href="<?php echo e(route('teamsix.show', ['admin' => $admin, 'missionnum' => '7' , 'passcode' => $passcode, 'teamsix' => $teamsix])); ?>">PLAY</a>
                </button>
            </div>
            <?php else: ?>
            <div class="md:hidden mb-8"></div>
            <?php endif; ?>
        </div>
        <div class="bg-white max-md:mb-2 px-4 py-3 rounded-xl <?php if($teamsix == '3'): ?> opacity-50 <?php endif; ?>">
            <h1 class="max-md:hidden text-sm text-black font-ibm tracking-wide">MISSION 6</h1>
            <h1 class="md:hidden text-sm text-black font-ibm tracking-wide">MISSION 8</h1>
            <h1 class="max-md:hidden -mt-1 text-base text-black font-ibm font-black tracking-widest">CRUISE SHIP</h1>
            <h1 class="md:hidden -mt-1 text-base text-black font-ibm font-black tracking-widest">BUS</h1>
            <div class="flex mb-1">
                <img src="<?php echo e(asset('dist/bomb.svg')); ?>" alt="">
                <h1 class="ml-2 text-sm text-slate-500 font-ibm font-bold">5 BOMB</h1>
            </div>
            <div class="flex mb-1">
                <img src="<?php echo e(asset('dist/time.svg')); ?>" alt="">
                <h1 class="ml-2 text-sm text-slate-500 font-ibm font-bold">40:00</h1>
            </div>
            <div class="flex w-fit -mb-6 gap-[1px]">
                <img src="<?php echo e(asset('dist/difficulty.svg')); ?>" alt="">
                <div class="ml-2 bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="bg-slate-500 md:bg-transparent border-0 md:border-2 border-slate-500 rounded-full w-4 h-4"></div>
            </div>
            <?php if($teamsix == '2'): ?>
            <div class="justify-end flex max-md:hidden">
                <button class="mr-0 w-fit bg-secondary px-4 py-1 rounded-lg text-base text-white font-ibm font-bold tracking-widest hover:bg-secondary/75"> 
                    <a href="<?php echo e(route('teamsix.show', ['admin' => $admin, 'missionnum' => '6' , 'passcode' => $passcode, 'teamsix' => $teamsix])); ?>">PLAY</a>
                </button>
            </div>
            <?php else: ?>
            <div class="md:hidden mb-8"></div>
            <?php endif; ?>
            <?php if($teamsix == '2'): ?>
            <div class="justify-end flex md:hidden">
                <button class="mr-0 w-fit bg-secondary px-4 py-1 rounded-lg text-base text-white font-ibm font-bold tracking-widest hover:bg-secondary/75"> 
                    <a href="<?php echo e(route('teamsix.show', ['admin' => $admin, 'missionnum' => '8' , 'passcode' => $passcode, 'teamsix' => $teamsix])); ?>">PLAY</a>
                </button>
            </div>
            <?php else: ?>
            <div class="md:hidden mb-8"></div>
            <?php endif; ?>
        </div>
        <div class="bg-white max-md:mb-2 px-4 py-3 rounded-xl  <?php if($teamsix == '2'): ?> opacity-50 <?php endif; ?>">
            <h1 class="text-sm text-black font-ibm tracking-wide">MISSION 9</h1>
            <h1 class="-mt-1 text-base text-black font-ibm font-black tracking-widest">BANK</h1>
            <div class="flex mb-1">
                <img src="<?php echo e(asset('dist/bomb.svg')); ?>" alt="">
                <h1 class="ml-2 text-sm text-slate-500 font-ibm font-bold">5 BOMB</h1>
            </div>
            <div class="flex mb-1">
                <img src="<?php echo e(asset('dist/time.svg')); ?>" alt="">
                <h1 class="ml-2 text-sm text-slate-500 font-ibm font-bold">40:00</h1>
            </div>
            <div class="flex w-fit -mb-6 gap-[1px]">
                <img src="<?php echo e(asset('dist/difficulty.svg')); ?>" alt="">
                <div class="ml-2 bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="bg-slate-500 rounded-full w-4 h-4"></div>
                <div class="bg-slate-500 rounded-full w-4 h-4"></div>
            </div>
            <?php if($teamsix == '3'): ?>
            <div class="justify-end flex">
                <button class="mr-0 w-fit bg-secondary px-4 py-1 rounded-lg text-base text-white font-ibm font-bold tracking-widest hover:bg-secondary/75"> 
                    <a href="<?php echo e(route('teamsix.show', ['admin' => $admin, 'missionnum' => '9' , 'passcode' => $passcode, 'teamsix' => $teamsix])); ?>">PLAY</a>
                </button>
            </div>
            <?php else: ?>
            <div class="md:hidden mb-8"></div>
            <?php endif; ?>
        </div>
    </div>
<script>
</script>
</body>
</html><?php /**PATH C:\Users\user\defusethebomb-ti\resources\views/defusethebomb/index.blade.php ENDPATH**/ ?>