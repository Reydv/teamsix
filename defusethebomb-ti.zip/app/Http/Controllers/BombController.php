<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Admin;
use App\Models\MissionConfig;
use Exception;
use Illuminate\Http\Request;

class BombController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Admin $admin)
    {
        $passcode = request('passcode');
        $teamSix = request('teamsix');

        $missionCom = $this->retrieveMissionCompleteArraySummary(json_decode($admin->misi_selesai, true));
        
        return view('defusethebomb/index', ['passcode' => $passcode, 'teamsix' => $teamSix, 'admin' => $admin, 'missionCom' => $missionCom]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Admin $admin)
    {
        $missionNum = request('missionnum');
        $passcode = request('passcode');
        $teamSix = request('teamsix');

        $missionCon = MissionConfig::all()->first();
        $time = json_decode($missionCon->missions_timer, true)[$missionNum];
        $story = strtoupper(config('mission-config.story.' . $missionNum));
        $bomb = config('mission-config.bomb.' . $missionNum);
        $missionName = $this->retreiveMissionName($missionNum);
        $missionTime = $this->retreiveMissionTimeName($time);

        // dd($missionNum, $passcode, $teamSix, $missionCon, $time, $story, $bomb, $missionName);

        return view('defusethebomb/show', ['missionTime' => $missionTime, 'missionNum' => $missionNum, 'missionName' => $missionName, 'time' => $time, '', 'story' => $story, 'bomb' => $bomb, 'teamsix' => $teamSix, 'passcode' => $passcode, 'admin' => $admin]);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    function teamSixCheck()
    {
        $passcode = 0;
        $teamSix = 0;

        $passcode = (int)request('passcode');
        $teamSix = (int)request('teamsix');

        $event = Admin::where('passcode', $passcode)
            ->where('teamsix', $teamSix)
            ->first();

        if ($event) {
            switch ($event->teamsix) {
                case 2:
                case 3:
                    return redirect()->route('teamsix.index', ['passcode' => $event->passcode, 'teamsix' => $event->teamsix, 'admin' => $event]);

                default:
                    abort('400');
                    break;
            }
        } else {
            abort('404');
        }
    }

    function checkPasscode()
    {
        $passcode = 0;
        $teamSix = 0;

        try {
            $passcode = (int)request('passcode');
            $teamSix = (int)request('teamsix');
        } catch (Exception $e) {
            abort(400);
        }

        $event = Admin::where('passcode', $passcode)
            ->where('teamsix', $teamSix)
            ->first();

        if ($event && $event->isOn == true) {
            return true;
        }

        return false;
    }

    function successFetch(Admin $admin)
    {
        // $isComplete = request('complete');
        // $missionNum = request('missionNum');
        // $uniqueSession = 

        // if($isComplete && $missionNum) {
        //     $iniArray[] =  $missionNum;
        // } 

        // $admin->misi_selesai = json_encode($iniArray);
        // $admin->save();
        return true;
    }

    private function retreiveMissionName($missionnum)
    {
        if ($missionnum == 0) {
            return 'MISSION 0 - TRAINING MISSION';
        } elseif ($missionnum == 1) {
            return 'MISSION 1 - CENTRAL STATION';
        } elseif ($missionnum == 2) {
            return 'MISSION 2 - TERMINAL';
        } elseif ($missionnum == 3) {
            return 'MISSION 3 - ELEVATOR';
        } elseif ($missionnum == 4) {
            return 'MISSION 4 - ROLLERCOASTER';
        } elseif ($missionnum == 5) {
            return 'MISSION 5 - SUBWAY';
        } elseif ($missionnum == 6) {
            return 'MISSION 6 - CRUISE SHIP';
        } elseif ($missionnum == 7) {
            return 'MISSION 7 - PRISON';
        } elseif ($missionnum == 8) {
            return 'MISSION 8 - BUS';
        } elseif ($missionnum == 9) {
            return 'MISSION 9 - BANK';
        } else {
            return 'MISSION';
        }
    }

    private function retreiveMissionTimeName($missionTime)
    {
        $minute = (int)floor($missionTime / 60);
        $second = $missionTime % 60;

        $time = $minute . ' Menit';
        if ($second != 0) {
            $time = $minute . ' MENIT ' . $second . ' DETIK';
        }

        return $time;
    }

    private function retrieveMissionCompleteArraySummary($array)
    {
        $completeArray = [];
        if (in_array(0, $array)) {
            $completeArray[0] = true;
        } 
        if (in_array(1, $array)) {
            $completeArray[1] = true;
        } 
        if (in_array(2, $array)) {
            $completeArray[2] = true;
        } 
        if (in_array(3, $array)) {
            $completeArray[3] = true;
        } 
        if (in_array(4, $array)) {
            $completeArray[4] = true;
        } 
        if (in_array(5, $array)) {
            $completeArray[5] = true;
        } 
        if (in_array(6, $array)) {
            $completeArray[6] = true;
        } 
        if (in_array(7, $array)) {
            $completeArray[7] = true;
        } 
        if (in_array(8, $array)) {
            $completeArray[8] = true;
        } 
        if (in_array(9, $array)) {
            $completeArray[9] = true;
        } 

        return $completeArray;
    }
}
