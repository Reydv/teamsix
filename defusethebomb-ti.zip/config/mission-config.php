<?php

return [
    'story' => [
        '0' => 'Anda masuk camp pelatihan Team six pasukan anti-teror terbaik. Misi ini bukan SEKEDAR LATIHAN keterampilan teknis menjinakan bom, TAPI membangun kepercayaan diri dan KOLABORASI tim. elemen kunci menjadi ANGGOTA TEAM SIX, pasukan khusus anti-teror terbaik',
        '1' => 'Agent, SEKARANGLAH misi sebenarnya, kami TEMUKAN sebuah bom di stasiun utama kota, jinakkan bom agar jalur transportasi utama tidak terputus, jika gagal akan terjadi kekacauan di kota KITA. Waktu kita SANGATLAH terbatas semoga kalian berhasil',
        '2' => 'laporan petugas kebersihan di terminal ada sebuah koper yang tetinggal dan mencurigakan, setelah diperiksa tim lapangan, koper itu adalah bom. Ini bukan hanya sebuah misi, tetapi tanggung jawab besar bagi kita semua. Keamanan dunia ada di tangan kita. LAKUKAN tugas ini dengan baik. ',
        '3' => 'Agent, misi KALI INI SELAMATKAN pengunjung di pusat perbelanjaan. Laporan menyatakan, bom terpasang di salah satu ELEVATOR. TIM LAPANGAN SEDANG mengevakuasi seluruh pengunjung, tugas kalian untuk menjinakkan BOM, tetap fokus dan hati-hati.',
        '4' => 'Agent! kalian akan bertugas kembali, para teroris masih berkeliaran diluar sana dan membuat teror baru. bom KALI INI DILAPORKAN BERADA DI wahana rollercoaster. Tim LAPANGAN KITA sedang mengevakuasi seluruh pengunjung dan mensterilkan area tersebut. Sekarang tugas kalian ANGGOTA TEAM SIX untuk menjinakkan bom ini. Semoga kalian berhasil.',
        '5' => 'Misi ini sangat berbahaya, kamera CCTV kereta bawah Tanah MENUNJUKAN teroris meletakkan bom, Anda kami tugaskan kembali melawan teroris dengan menjinakkan bom tersebut. Gunakan semua kemampuan kalian, bom ini canggih dan sulit untuk dijinakkan, semoga berhasil.',
        '6' => 'AGENT! Maaf mengganggu waktu libur kalian, laporan baru KAPTEN kapal pesiar MENGENAI bom dikapal mereka yang sedang berlayar. tidak ada cara lain untuk menyelamatkan para penumpang selain menjinakkan bom tersebut, helikopter AKAN membawa kalian menuju kapal pesiar. Jinakkan bom itu demi keselamatan seluruh penumpang.',
        '7' => 'Hai agent! PARA teroris sangat marah kepada kalian, seorang teroris YANG tertangkap AKAN melakukan tindakan bunuh diri dengan memasang bom di penjara, kami tidak tau bagaimana dia membuat bom tersebut di DALAM penjara, sangat berbahaya jika para tahanan lainnya bisa bebas dari sana, jinakkan bom itu secepatnya.',
        '8' => 'Hai agent-agent terbaik kami. Kali ini tugas sangat berat menanti. Dilaporkan SEBUAH bus yang sedang mengangkut tamu-tamu penting negara TERPASANG bom yang sangat canggih. Kali ini kami harap kalian bisa menjinakkan bom tersebut dengan baik, semoga tuhan bersama kalian.',
        '9' => 'Hai agent para teroris telah membobol bank nasional kita. Jika bank meledak kami tidak dapat membayangkan akibatnya terhadap stabilitas ekonomi kita, jinakkan bom canggih ini, kami percaya kalian bisa, semoga berhasil.',
    ],
    'bomb' => [
        '0' => [
            '1' => '21490', 
            '2' => '12148', 
            '3' => '01912'
        ],  
        '1' => [
            '1' => '52347', 
            '2' => '23740', 
            '3' => '53480',
            '4' => '13654',
            '5' => '32213',
        ],  
        '2' => [
            '1' => '41821', 
            '2' => '84707', 
            '3' => '26359',
            '4' => '21743',
            '5' => '36250',
        ],  
        '3' => [
            '1' => '87459', 
            '2' => '20832', 
            '3' => '12271',
            '4' => '72883',
            '5' => '23324',
        ],  
        '4' => [
            '1' => '43608', 
            '2' => '12148', 
            '3' => '97589',
            '4' => '31808',
            '5' => '26208',
        ],  
        '5' => [
            '1' => '50328', 
            '2' => '38129', 
            '3' => '93638',
            '4' => '84810',
            '5' => '21468',
        ],  
        '6' => [
            '1' => '32460', 
            '2' => '29357', 
            '3' => '73625',
            '4' => '42138',
            '5' => '09863',
        ],  
        '7' => [
            '1' => '05450', 
            '2' => '32738', 
            '3' => '21945',
            '4' => '02372',
            '5' => '35426',
        ],  
        '8' => [
            '1' => '36047', 
            '2' => '55371', 
            '3' => '96378',
            '4' => '83759',
            '5' => '51347',
        ],  
        '9' => [
            '1' => '07734', 
            '2' => '54781', 
            '3' => '37269',
            '4' => '46029',
            '5' => '84372',
        ],  
    ],
    'hint' => [],
];